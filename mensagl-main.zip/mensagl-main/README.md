# AWS-ASO
RETO EQUIPO 5 - MENSAGL. Scripts de montaje (VPCs, EC2, automatizacion de aplicaciones, etc.)
USO DE:
- AWS-CLI
- AWS CLOUDFORMATION